function startcc8(hasFilter) {
    const cc8 = document.querySelector('#cc8');

    if (hasFilter) {
        cc8.classList.add('has-filter');
    } else {
    }

    cc8.classList.remove('ccg');
}

function endcc8() {
    const cc8 = document.querySelector('#cc8');
    cc8.classList.add('ccg');
}