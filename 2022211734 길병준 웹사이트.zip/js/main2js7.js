function startcc7(hasFilter) {
    const cc7 = document.querySelector('#cc7');

    if (hasFilter) {
        cc7.classList.add('has-filter');
    } else {
    }

    cc7.classList.remove('ccg');
}

function endcc7() {
    const cc7 = document.querySelector('#cc7');
    cc7.classList.add('ccg');
}