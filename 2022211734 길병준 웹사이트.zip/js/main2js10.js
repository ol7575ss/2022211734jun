function startcc10(hasFilter) {
    const cc10 = document.querySelector('#cc10');

    if (hasFilter) {
        cc10.classList.add('has-filter');
    } else {
    }

    cc10.classList.remove('ccg');
}

function endcc10() {
    const cc10 = document.querySelector('#cc10');
    cc10.classList.add('ccg');
}