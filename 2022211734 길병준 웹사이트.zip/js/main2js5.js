function startcc5(hasFilter) {
    const cc5 = document.querySelector('#cc5');

    if (hasFilter) {
        cc5.classList.add('has-filter');
    } else {
    }

    cc5.classList.remove('ccg');
}

function endcc5() {
    const cc5 = document.querySelector('#cc5');
    cc5.classList.add('ccg');
}