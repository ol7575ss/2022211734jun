function startcc1(hasFilter) {
    const cc1 = document.querySelector('#cc1');

    if (hasFilter) {
        cc1.classList.add('has-filter');
    } else {
    }

    cc1.classList.remove('ccg');
}

function endcc1() {
    const cc1 = document.querySelector('#cc1');
    cc1.classList.add('ccg');
}