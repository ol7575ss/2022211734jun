function startcc3(hasFilter) {
    const cc2 = document.querySelector('#cc3');

    if (hasFilter) {
        cc3.classList.add('has-filter');
    } else {
    }

    cc3.classList.remove('ccg');
}

function endcc3() {
    const cc3 = document.querySelector('#cc3');
    cc3.classList.add('ccg');
}