function startcc9(hasFilter) {
    const cc9 = document.querySelector('#cc9');

    if (hasFilter) {
        cc9.classList.add('has-filter');
    } else {
    }

    cc9.classList.remove('ccg');
}

function endcc9() {
    const cc9 = document.querySelector('#cc9');
    cc9.classList.add('ccg');
}