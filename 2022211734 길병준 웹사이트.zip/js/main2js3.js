function startcc2(hasFilter) {
    const cc2 = document.querySelector('#cc2');

    if (hasFilter) {
        cc2.classList.add('has-filter');
    } else {
    }

    cc2.classList.remove('ccg');
}

function endcc2() {
    const cc2 = document.querySelector('#cc2');
    cc2.classList.add('ccg');
}