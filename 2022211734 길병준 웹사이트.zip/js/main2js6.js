function startcc6(hasFilter) {
    const cc6 = document.querySelector('#cc6');

    if (hasFilter) {
        cc6.classList.add('has-filter');
    } else {
    }

    cc6.classList.remove('ccg');
}

function endcc6() {
    const cc6 = document.querySelector('#cc6');
    cc6.classList.add('ccg');
}