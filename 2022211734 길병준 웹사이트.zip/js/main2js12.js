function startcc12(hasFilter) {
    const cc12 = document.querySelector('#cc12');

    if (hasFilter) {
        cc12.classList.add('has-filter');
    } else {
    }

    cc12.classList.remove('ccg');
}

function endcc12() {
    const cc12 = document.querySelector('#cc12');
    cc12.classList.add('ccg');
}