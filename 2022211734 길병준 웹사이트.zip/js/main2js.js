function startcc(hasFilter) {
    const cc = document.querySelector('#cc');

    if (hasFilter) {
        cc.classList.add('has-filter');
    } else {
    }

    cc.classList.remove('ccg');
}

function endcc() {
    const cc = document.querySelector('#cc');
    cc.classList.add('ccg');
}