function startcc11(hasFilter) {
    const cc11 = document.querySelector('#cc11');

    if (hasFilter) {
        cc11.classList.add('has-filter');
    } else {
    }

    cc11.classList.remove('ccg');
}

function endcc11() {
    const cc11 = document.querySelector('#cc11');
    cc11.classList.add('ccg');
}